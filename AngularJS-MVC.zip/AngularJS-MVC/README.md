AngularJS MVC Web App Template
==============================

A starter template for an AngularJS Web Application with a MVC folder structure.

Uses AngularJS 1.3.0, jQuery 2.1.1, Twitter Bootstrap 3.3.0, Flat UI as CDNs &amp; HTML5


This is a customised version of a combination of two similar starter templates built for a similar purpose:

* https://github.com/kajackdfw/angular_bootstrap_app
* https://github.com/davidb583/white-angularjs-app
